import React from 'react';
import './App.css';
import "react-table/react-table.css"; 
import "./table.css" 
import ReactTable from "react-table";  
import Props from './Props.js';
import PropsVal from './PropsVal.js';
import Display from './Display.js';

var data = [
  {id: 1, name: 'Gob', email: 'gob@xyz.com'},
  {id: 2, name: 'Buster', email: 'buster@xyz.com'},
  {id: 3, name: 'George', email: 'george@xyz.com'},
  {id: 4, name: 'Michael', email: 'michael@xyz.com'},
  {id: 5, name: 'John', email: 'john@xyz.com'}
];
var columns = [
	{ Header: 'Employee ID', accessor: 'id' },
	{ Header: 'Employee Name', accessor: 'name' },
	{ Header: 'E-Mail', accessor: 'email' }
];
const elements = [1, 2, 3,4, 5, 6, 7, 8, 9, 10];
const items = []

for (const [index, value] of elements.entries()) {
items.push(<li>5 X {value} = {5*value}</li>)
}
function App() {
  return (
    <div className="App">
        <p><h1>Happy Learning - React!</h1></p>
        <h4 className="Table-header">Basic Table</h4>
        <ReactTable  
            data={data}  
            columns={columns}  
			defaultPageSize = {5} 
			showPagination={false}
        />  
		<p>
			<h4>Multiples of 5</h4>
			<ul>{items}</ul>	
		</p>
		<div>
			<Display/>
			<Props companyName="ABC" companyLocation="XYZ"/>
			<PropsVal Name="Nikhil" PreferredCities={['XYZ','PQR']} Age={25}/>
		</div>
    </div>
  );
}

export default App;
