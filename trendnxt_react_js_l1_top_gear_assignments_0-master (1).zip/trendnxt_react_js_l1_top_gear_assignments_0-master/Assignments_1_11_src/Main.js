import React from 'react';
import "./students.css";

export default class Main extends React.Component {
  constructor() {
    super();
    this.state = {
		students: [
		{ id: 1, name: 'Gob', marks: 78 },
		{ id: 2, name: 'Bob', marks: 85 },
		{ id: 3, name: 'Robb', marks: 54 },
		{ id: 4, name: 'Tom', marks: 97 },
		{ id: 5, name: 'John', marks: 75 }
		]
	};
  }
  render() {
		return (
		
			<div className="students">
				<table>
				<tbody>
					<tr><th>ID</th><th>Name</th><th>Marks</th></tr>
					{this.state.students.map((_stu, _id) => {
						return (
						<tr>
							<td>{_stu.id}</td>
							<td>{_stu.name}</td>
							<td>{_stu.marks}</td>
						</tr>
						);
					})}
					</tbody>
				</table>
				
			</div>
			
		);
	}
}