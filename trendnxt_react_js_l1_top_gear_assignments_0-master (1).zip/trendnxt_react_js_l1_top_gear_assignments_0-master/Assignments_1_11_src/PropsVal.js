import React from 'react';
import PropTypes from 'prop-types';
import Form from './Form.js'

export default class PropsVal extends React.Component {
  constructor(props) {
    super(props);
	this.displayData = [];
    this.state = {
		count: 1,
		disabled: false,
		showdata : this.displayData
	}
	this.appendData = this.appendData.bind(this);
  }
  appendData() {
		if(this.state.count===10){
			this.setState({
				disabled : true
			});
		}
		this.setState(prevCount => {
			this.state.count = prevCount.count+1
		});
		this.setState({
            showdata : this.displayData
        });
		this.displayData.push(<tr><td>5 X {this.state.count} = {this.state.count * 5}</td></tr>);
      }
  render() {
		const mystyle = {
			width:"10%",
			margin:"0 auto"
		};
		return (
		
			<div>
				<p>I am {this.props.Name}, {this.props.Age}, I prefer to work in {this.props.PreferredCities}</p>
				<button onClick={this.appendData} disabled={this.state.disabled} >Click to generate Multiplication tables of 5</button>
				<div id="display-data-Container">
				<table style={mystyle}><tbody>{this.displayData}</tbody></table>
				</div>
				<Form/>
			</div>
		);
	}
}

PropsVal.propTypes = {
  Name: PropTypes.string.isRequired,
  PreferredCities: PropTypes.arrayOf(PropTypes.string),
  Age: PropTypes.number
};

PropsVal.defaultProps = {
  Name: 'Steve',
  PreferredCities: ['BANGALORE','CHENNAI'],
  Age: 18
};