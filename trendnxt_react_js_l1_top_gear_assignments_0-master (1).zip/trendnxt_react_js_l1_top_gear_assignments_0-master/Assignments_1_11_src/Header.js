import React from 'react';

export default class Header extends React.Component {
	render(){
       return(
           <div>
               <h1>Student Details</h1>
           </div>   
        )
	}
}