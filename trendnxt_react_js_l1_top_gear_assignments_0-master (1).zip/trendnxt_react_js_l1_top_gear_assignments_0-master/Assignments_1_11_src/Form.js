import React from 'react';
export default class Form extends React.Component {
	constructor(props) {
		super(props);
		this.state = {p:0, c:0, m:0, b:0, avg:0};

		this.Calcuate = this.Calcuate.bind(this);
	}
	Calcuate(event) {
		this.setState({
			avg: parseInt(this.state.p) + parseInt(this.state.c) + parseInt(this.state.m) + parseInt(this.state.b)
		}, function() {
			alert('P :'+this.state.p+'\nC :'+this.state.c+'\nM :'+this.state.m+'\nB :'+this.state.b+'\nAverage is '+(this.state.avg/4))
		});
		event.preventDefault();
	}
 render () {
	
   return (
     <form className="demoForm" onSubmit={this.Calcuate}>
       <h2>Average Calculator</h2>
       <div className="form-group">
         <label htmlFor="phy">Physics</label>
         <input type="number" className="form-control" name="phy" value={this.state.p} onChange={e => this.setState({ p: e.target.value })}/>
       </div>
       <div className="form-group">
         <label htmlFor="chem">Chemistry</label>
         <input type="number" className="form-control" name="chem" value={this.state.c} onChange={e => this.setState({ c: e.target.value })}/>
       </div>
	   <div className="form-group">
         <label htmlFor="math">Maths</label>
         <input type="number" className="form-control" name="math" value={this.state.m} onChange={e => this.setState({ m: e.target.value })}/>
       </div>
       <div className="form-group">
         <label htmlFor="bio">Biology</label>
         <input type="number" className="form-control" name="bio" value={this.state.b} onChange={e => this.setState({ b: e.target.value })}/>
       </div>
       <button type="submit" className="btn btn-primary">
          Find Average
       </button>
     </form>
   )
 }
}