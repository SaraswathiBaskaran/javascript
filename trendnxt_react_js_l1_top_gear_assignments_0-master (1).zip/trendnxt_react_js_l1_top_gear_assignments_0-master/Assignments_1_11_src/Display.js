import React from 'react';
import Main from './Main.js'
import Header from './Header.js'
export default class Display extends React.Component {
	constructor(props) {
	  super(props);
	  this.state = { show: true };
	}
	delHeader = () => {
		this.setState({show: false});
	}
	
	render(){
		let myheader;
		if (this.state.show) {
		  myheader = <Child />;
		};
       return(
           <div>
               <Header/>
			   <Main/>
			   <div onClick={this.delHeader}>{myheader}</div>
		   </div>   
        )
	}
}

class Child extends React.Component {
	
	constructor(props) {
	  super(props);
	  this.state = { mounted: false };
	}
	componentWillMount() {
		alert("Thought for the day is about to be mounted.");
	}
	componentDidMount() {
		
		alert("Thought for the day is mounted.");
	}
	componentWillUnmount() {
		this.setState({ mounted: true });
		alert("Thought for the day is about to be unmounted.");
	}
	render() {
	var style1 = {
        color:'red'
    };
	var style2 = {
        color:'blue'
    };
		return (
		<h1 style={this.state.mounted ? style1 : style2}>You must decide whether to insist upon the absolute correctness of your view, or to listen and negotiate. You don't get peace by being right.</h1>
		);
	}
}
