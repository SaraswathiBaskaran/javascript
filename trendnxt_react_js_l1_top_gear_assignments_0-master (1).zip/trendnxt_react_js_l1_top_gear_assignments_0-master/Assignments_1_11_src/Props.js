import React from 'react';
import PropTypes from 'prop-types';

export default class Props extends React.Component {
  
  render() {
		return (
		
			<div>
				<p>I work in {this.props.companyName} at {this.props.companyLocation}</p>
			</div>
			
		);
	}
}

Props.propTypes = {
  companyName: PropTypes.string,
  companyLocation: PropTypes.string
};

Props.defaultProps = {
  companyName: 'WIPRO',
  companyLocation: 'BANGALORE'
};