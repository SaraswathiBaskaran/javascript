import React from 'react';
import './add.css';
import './inventory.css';
const Row = ({movieid, moviename, leadactor, leadactress, yearofrelease, language, remove}) => (
  <div className="row">
    <div>{movieid}</div>
    <div>{moviename}</div>
    <div>{leadactor}</div>
    <div>{leadactress}</div>    
    <div>{yearofrelease}</div> 
	<div>{language}</div> 
	<div className="remove">
      <a style={{color:"red"}} href="#" onClick={() => remove(movieid)}>X</a>
    </div>
  </div>
);

class Add extends React.Component {
  constructor(props) {
		super(props);
		this.state = {
		movies: [
			{movieid: 1, moviename: 'Black Panther', leadactor: 'Chadwick Boseman', leadactress: 'Lupita Nyong\'o', yearofrelease: '2018', language:'english'},
			{movieid: 2, moviename: 'Bohemian Rhapsody ', leadactor: 'Rami Malek', leadactress: 'Lucy Boynton', yearofrelease: '2018', language:'english'},
			{movieid: 3, moviename: 'A Star Is Born', leadactor: 'Bradley Cooper', leadactress: '	Lady Gaga', yearofrelease: '2018', language:'english'},
			{movieid: 4, moviename: 'The Shape of Water', leadactor: 'Michael Shannon', leadactress: 'Sally Hawkins', yearofrelease: '2017', language:'english'},
			{movieid: 5, moviename: 'Dunkirk', leadactor: 'Fionn Whitehead', leadactress: '', yearofrelease: '2017', language:'english'}
			],
		showing: true,
		tblshowing: false,
		};

		this.addMovie = this.addMovie.bind(this);
	}
	
	addMovie(event) {
		event.preventDefault();
		const a1 = this.state.amovieid;
		const b1 = this.state.amoviename;
		const c1 = this.state.aleadactor;
		const d1 = this.state.aleadactress;
		const e1 = this.state.ayearofrelease;
		const f1 = this.state.alanguage;
		const obj = {'movieid':parseInt(a1), 'moviename':b1, 'leadactor':c1, 'leadactress':d1, 'yearofrelease':e1, 'language':f1};
		   
		this.setState({movies: [...this.state.movies, obj], showing: false, tblshowing: true}, () => {console.log(this.state.movies); });
    
	}
	remove = (rowId) => {
    // Array.prototype.filter returns new array
    // so we aren't mutating state here
    const arrayCopy = this.state.movies.filter((row) => row.movieid !== rowId);
    this.setState({movies: arrayCopy});
  };
  compareBy = (key) => {
    return function(a, b) {
    if (a[key] < b[key]) return -1;
    if (a[key] > b[key]) return 1;
    return 0;
    };
  };
   
  sortBy = (key) => {
    let arrayCopy = [...this.state.movies];
    arrayCopy.sort(this.compareBy(key));
    this.setState({movies: arrayCopy});
  };
 render () {
	 const { showing } = this.state;
	 const { tblshowing } = this.state;
	 const rows = this.state.movies.map( (rowData) => <Row remove={this.remove} {...rowData } />);
   return (
   <div>
     <form className="demoForm" onSubmit={this.addMovie} style={{ display: (showing ? 'block' : 'none') }}>
       <h2>Add a Movie</h2>
	   
			   <div className="form-group">
				 <label htmlFor="movieid">Movie ID</label>
				 <input type="number" className="form-control" name="movieid" value={this.state.amovieid} onChange={e => this.setState({ amovieid: e.target.value })}/>
			   </div>
			   <div className="form-group">
				 <label htmlFor="moviename">Movie Name</label>
				 <input type="text" className="form-control" name="moviename" value={this.state.amoviename} onChange={e => this.setState({ amoviename: e.target.value })}/>
			   </div>
			   <div className="form-group">
				 <label htmlFor="leadactor">Lead Actor</label>
				 <input type="text" className="form-control" name="leadactor" value={this.state.aleadactor} onChange={e => this.setState({ aleadactor: e.target.value })}/>
			   </div>
			   <div className="form-group">
				 <label htmlFor="leadactress">Lead Actress</label>
				 <input type="text" className="form-control" name="leadactress" value={this.state.aleadactress} onChange={e => this.setState({ aleadactress: e.target.value })}/>
			   </div>
			   <div className="form-group">
				 <label htmlFor="yeearofrelease">Year of Release</label>
				 <input type="text" className="form-control" name="yeearofrelease" value={this.state.ayearofrelease} onChange={e => this.setState({ ayearofrelease: e.target.value })}/>
			   </div>
			   <div className="form-group">
				 <label htmlFor="language">Language</label>
				 <input type="text" className="form-control" name="language" value={this.state.alanguage} onChange={e => this.setState({ alanguage: e.target.value })}/>
			   </div>
	   <div id="wrapper">
		   <button type="submit" className="btn btn-primary">
			  Add
		   </button>
	   </div>
     </form>
		<div className="table" style={{ display: (tblshowing ? 'block' : 'none') }}>
			<h3>Movie Details</h3>
			<div className="header">
				<div onClick={() => this.sortBy('movieid')} >ID</div>
				<div onClick={() => this.sortBy('moviename')}>Name</div>
				<div onClick={() => this.sortBy('leadactor')}>Lead Actor</div>
				<div onClick={() => this.sortBy('leadactress')}>Lead Actress</div>
				<div onClick={() => this.sortBy('yearofrelease')}>Year of Release</div>
				<div onClick={() => this.sortBy('language')}>Language</div>
				<div className="remove"></div>
			</div>
			<div className="body">
				{rows}
			</div>
		</div>
	</div>
   )
 }
}
export default Add