import React from 'react';
import './App.css'; 
import Inventory from './inventory';

function App() {
  return (
    <div className="App">
      <header className="App-header">
	  <h3>Movie Details Management</h3>
        <Inventory/>
      </header>
    </div>
  );
}

export default App;
