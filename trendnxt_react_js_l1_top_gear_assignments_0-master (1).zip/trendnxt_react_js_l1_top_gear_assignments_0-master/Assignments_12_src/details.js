import React from 'react';
import './details.css';

class Details extends React.Component {
	state = {
		movies: [
		{movieid: 1, moviename: 'Black Panther', leadactor: 'Chadwick Boseman', leadactress: 'Lupita Nyong\'o', yearofrelease: '2018', language:'english'},
		{movieid: 2, moviename: 'Bohemian Rhapsody ', leadactor: 'Rami Malek', leadactress: 'Lucy Boynton', yearofrelease: '2018', language:'english'},
		{movieid: 3, moviename: 'A Star Is Born', leadactor: 'Bradley Cooper', leadactress: '	Lady Gaga', yearofrelease: '2018', language:'english'},
		{movieid: 4, moviename: 'The Shape of Water', leadactor: 'Michael Shannon', leadactress: 'Sally Hawkins', yearofrelease: '2017', language:'english'},
		{movieid: 5, moviename: 'Dunkirk', leadactor: 'Fionn Whitehead', leadactress: '', yearofrelease: '2017', language:'english'}
		]
	};
	constructor(props) {
     super(props);
	 var id = props.match.params.id;
	 //alert(this.b(id))
	 //alert(id)
	 //this.setState({mid: this.id}, ()=> {alert(this.state.mid)});
	}
	
	componentWillMount(){ 
		this.setState({ 
			mov_id : this.props.match.params.id
		})
	}
	b(idToSearch) {
		return this.state.movies.filter(item => {
		return item.movieid === idToSearch
		})
	};
  render() {
	
    return (
		<div>
			<h1>Movie Details</h1>
			<div className="body">
			<table className="individual">
				<tbody>
					<tr><th>ID</th><th>Name</th><th>Lead Actor</th><th>Lead Actress</th><th>Year of Release</th><th>Language</th></tr>
					{this.state.movies.map((_stu, _id) => {
						if (_stu.movieid == this.state.mov_id) {
							return (
							<tr>
								<td>{_stu.movieid}</td>
								<td>{_stu.moviename}</td>
								<td>{_stu.leadactor}</td>
								<td>{_stu.leadactress}</td>
								<td>{_stu.yearofrelease}</td>
								<td>{_stu.language}</td>
							</tr>
							);
						}
					})}
				</tbody>
			</table>
			</div>
		</div>
	);
  }
}
export default Details