import React from 'react';
import './inventory.css';

const Row = ({movieid, moviename, leadactor, leadactress, yearofrelease, language, remove}) => (
  <div className="row">
    <div>{movieid}</div>
    <div>{moviename}</div>
    <div>{leadactor}</div>
    <div>{leadactress}</div>    
    <div>{yearofrelease}</div> 
	<div>{language}</div> 
	<div className="remove">
      <a style={{color:"red"}} href="#" onClick={() => remove(movieid)}>X</a>
    </div>
  </div>
);

class Inventory extends React.Component {
	state = {
		movies: [
		{movieid: 1, moviename: 'Black Panther', leadactor: 'Chadwick Boseman', leadactress: 'Lupita Nyong\'o', yearofrelease: '2018', language:'english'},
		{movieid: 2, moviename: 'Bohemian Rhapsody ', leadactor: 'Rami Malek', leadactress: 'Lucy Boynton', yearofrelease: '2018', language:'english'},
		{movieid: 3, moviename: 'A Star Is Born', leadactor: 'Bradley Cooper', leadactress: '	Lady Gaga', yearofrelease: '2018', language:'english'},
		{movieid: 4, moviename: 'The Shape of Water', leadactor: 'Michael Shannon', leadactress: 'Sally Hawkins', yearofrelease: '2017', language:'english'},
		{movieid: 5, moviename: 'Dunkirk', leadactor: 'Fionn Whitehead', leadactress: '', yearofrelease: '2017', language:'english'}
		]
	};
  
  remove = (rowId) => {
    // Array.prototype.filter returns new array
    // so we aren't mutating state here
    const arrayCopy = this.state.movies.filter((row) => row.movieid !== rowId);
    this.setState({movies: arrayCopy});
  };
  compareBy = (key) => {
    return function(a, b) {
    if (a[key] < b[key]) return -1;
    if (a[key] > b[key]) return 1;
    return 0;
    };
  };
   
  sortBy = (key) => {
    let arrayCopy = [...this.state.movies];
    arrayCopy.sort(this.compareBy(key));
    this.setState({movies: arrayCopy});
  };
  
	render() {
		const rows = this.state.movies.map( (rowData) => <Row remove={this.remove} {...rowData } />);
	
    return (
		<div className="table">
			<div className="header">
				<div onClick={() => this.sortBy('movieid')} >ID</div>
				<div onClick={() => this.sortBy('moviename')}>Name</div>
				<div onClick={() => this.sortBy('leadactor')}>Lead Actor</div>
				<div onClick={() => this.sortBy('leadactress')}>Lead Actress</div>
				<div onClick={() => this.sortBy('yearofrelease')}>Year of Release</div>
				<div onClick={() => this.sortBy('language')}>Language</div>
				<div className="remove"></div>
			</div>
			<div className="body">
				{rows}
			</div>
		</div>
	);
  }
}
export default Inventory